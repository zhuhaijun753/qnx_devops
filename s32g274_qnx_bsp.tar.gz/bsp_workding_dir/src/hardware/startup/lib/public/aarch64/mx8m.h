/*
 * $QNXLicenseC:
 * Copyright 2016, QNX Software Systems.
 * Copyright 2016, Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#ifndef IMX8QM_SOC_H_
#define IMX8QM_SOC_H_

/*
 * Cache Coherent Interconnect 400 (CCI400)
 */
#define IMX_CCI400_BASE                        0x52000000   /* CCCI400 BASE address, CBAR register value */

/*
 * Generic interrupt controller (GIC)
 */
#define IMX_GIC_GICD_BASE                      0x51A00000   /* CPU distributor BASE address */
#define IMX_GIC_GICR_BASE                      0x51B00000   /* CPU redistributor BASE address */
#define IMX_GIC_GICC_BASE                      0x52000000   /* CPU interface, CBAR register value */

/*
 * LVDS
 */
#define IMX_DC0_LVDS_BASE                      0x56240000
#define IMX_DC1_LVDS_BASE                      0x57240000

#define IMX_DC0_LVDS_IRQ                       89
#define IMX_DC1_LVDS_IRQ                       90

#define IMX_DC0_LVDS_STEER_IRQ0                800
#define IMX_DC1_LVDS_STEER_IRQ0                (IMX_DC0_LVDS_STEER_IRQ0 + 32)
/*
 * MIPI
 */
#define IMX_DC0_MIPI_BASE                      0x56220000
#define IMX_DC1_MIPI_BASE                      0x57220000

#define IMX_DC0_MIPI_IRQ                       91
#define IMX_DC1_MIPI_IRQ                       92

#define IMX_DC0_MIPI_STEER_IRQ0                (IMX_DC1_LVDS_STEER_IRQ0 + 32)
#define IMX_DC1_MIPI_STEER_IRQ0                (IMX_DC0_MIPI_STEER_IRQ0 + 32)
/*
 * CSI
 */
#define IMX_MIPI_CSI0_BASE                     0x58220000
#define IMX_MIPI_CSI1_BASE                     0x58240000

#define IMX_MIPI_CSI0_IRQ                      352
#define IMX_MIPI_CSI1_IRQ                      353

#define IMX_MIPI_CSI0_STEER_IRQ0               (IMX_DC1_MIPI_STEER_IRQ0 + 32)
#define IMX_MIPI_CSI1_STEER_IRQ0               (IMX_MIPI_CSI0_STEER_IRQ0 + 32)
/*
 * HDMI
 */
#define IMX_HDMI_RX_BASE                       0x58260000
#define IMX_HDMI_TX_BASE                       0x56260000

#define IMX_HDMI_RX_IRQ                        354
#define IMX_HDMI_TX_IRQ                        93

#define IMX_HDMI_RX_STEER_IRQ0                 (IMX_MIPI_CSI1_STEER_IRQ0 + 32)
#define IMX_HDMI_TX_STEER_IRQ0                 (IMX_HDMI_RX_STEER_IRQ0 + 32)

/*
 * INTMUX from Cortex-M4 subsystem
 */
#define IMX_M40_INTMUX_BASE                    0x37400000
#define IMX_M40_INTMUX_SIZE                    0x1000
#define IMX_M40_INTMUX_IRQ0                    48
#define IMX_M40_INTMUX_BASE_IRQ0               (IMX_HDMI_TX_STEER_IRQ0 + 32)
#define IMX_M40_INTMUX_IRQ1                    49
#define IMX_M40_INTMUX_BASE_IRQ1               (IMX_M40_INTMUX_BASE_IRQ0 + 32)
#define IMX_M40_INTMUX_IRQ2                    50
#define IMX_M40_INTMUX_BASE_IRQ2               (IMX_M40_INTMUX_BASE_IRQ1 + 32)
#define IMX_M40_INTMUX_IRQ3                    51
#define IMX_M40_INTMUX_BASE_IRQ3               (IMX_M40_INTMUX_BASE_IRQ2 + 32)
#define IMX_M40_INTMUX_IRQ4                    52
#define IMX_M40_INTMUX_BASE_IRQ4               (IMX_M40_INTMUX_BASE_IRQ3 + 32)
#define IMX_M40_INTMUX_IRQ5                    53
#define IMX_M40_INTMUX_BASE_IRQ5               (IMX_M40_INTMUX_BASE_IRQ4 + 32)
#define IMX_M40_INTMUX_IRQ6                    54
#define IMX_M40_INTMUX_BASE_IRQ6               (IMX_M40_INTMUX_BASE_IRQ5 + 32)
#define IMX_M40_INTMUX_IRQ7                    55
#define IMX_M40_INTMUX_BASE_IRQ7               (IMX_M40_INTMUX_BASE_IRQ6 + 32)

#define IMX_M41_INTMUX_BASE                    0x3B400000
#define IMX_M41_INTMUX_SIZE                    0x1000
#define IMX_M41_INTMUX_IRQ0                    56
#define IMX_M41_INTMUX_BASE_IRQ0               (IMX_M40_INTMUX_BASE_IRQ7 + 32)
#define IMX_M41_INTMUX_IRQ1                    57
#define IMX_M41_INTMUX_BASE_IRQ1               (IMX_M41_INTMUX_BASE_IRQ0 + 32)
#define IMX_M41_INTMUX_IRQ2                    58
#define IMX_M41_INTMUX_BASE_IRQ2               (IMX_M41_INTMUX_BASE_IRQ1 + 32)
#define IMX_M41_INTMUX_IRQ3                    59
#define IMX_M41_INTMUX_BASE_IRQ3               (IMX_M41_INTMUX_BASE_IRQ2 + 32)
#define IMX_M41_INTMUX_IRQ4                    60
#define IMX_M41_INTMUX_BASE_IRQ4               (IMX_M41_INTMUX_BASE_IRQ3 + 32)
#define IMX_M41_INTMUX_IRQ5                    61
#define IMX_M41_INTMUX_BASE_IRQ5               (IMX_M41_INTMUX_BASE_IRQ4 + 32)
#define IMX_M41_INTMUX_IRQ6                    62
#define IMX_M41_INTMUX_BASE_IRQ6               (IMX_M41_INTMUX_BASE_IRQ5 + 32)
#define IMX_M41_INTMUX_IRQ7                    63
#define IMX_M41_INTMUX_BASE_IRQ7               (IMX_M41_INTMUX_BASE_IRQ6 + 32)

/*
 * General Purpose Input/Output (GPIO)
 */
#define IMX_GPIO0_BASE                         0x5D080000
#define IMX_GPIO1_BASE                         0x5D090000
#define IMX_GPIO2_BASE                         0x5D0A0000
#define IMX_GPIO3_BASE                         0x5D0B0000
#define IMX_GPIO4_BASE                         0x5D0C0000
#define IMX_GPIO5_BASE                         0x5D0D0000
#define IMX_GPIO6_BASE                         0x5D0E0000
#define IMX_GPIO7_BASE                         0x5D0F0000

#define IMX_GPIO_SIZE                          0x10000

#define IMX_GPIO0_IRQ                          168
#define IMX_GPIO1_IRQ                          169
#define IMX_GPIO2_IRQ                          170
#define IMX_GPIO3_IRQ                          171
#define IMX_GPIO4_IRQ                          172
#define IMX_GPIO5_IRQ                          173
#define IMX_GPIO6_IRQ                          174
#define IMX_GPIO7_IRQ                          175

/*
 * General Purpose Timer (GPT)
 */
#define IMX_GPT0_BASE                          0x5D140000
#define IMX_GPT1_BASE                          0x5D150000
#define IMX_GPT2_BASE                          0x5D160000
#define IMX_GPT3_BASE                          0x5D170000
#define IMX_GPT4_BASE                          0x5D180000

#define IMX_GPT_SIZE                           0x10000

#define IMX_GPT0_IRQ                           112
#define IMX_GPT1_IRQ                           113
#define IMX_GPT2_IRQ                           114
#define IMX_GPT3_IRQ                           115
#define IMX_GPT4_IRQ                           116


/*
 * High Speed I/O Subsystem (HSIO)
 */
#define IMX_HSIO_BASE                           0x5F000000
/* GPIO */
#define IMX_HSIO_GPIO_BASE                      0x5F170000
#define IMX_HSIO_GPIO_SIZE                      0x10000
/* SYS.CSR */
#define IMX_HSIO_CRR_MISC_BASE                  0x5F160000
#define IMX_HSIO_CRR_MISC_SIZE                  0x10000
#define IMX_HSIO_CRR_SATA0_BASE                 0x5F150000
#define IMX_HSIO_CRR_SATA0_SIZE                 0x10000
#define IMX_HSIO_CRR_PCIEX1_BASE                0x5F140000
#define IMX_HSIO_CRR_PCIEX1_SIZE                0x10000
#define IMX_HSIO_CRR_PCIEX2_BASE                0x5F130000
#define IMX_HSIO_CRR_PCIEX2_SIZE                0x10000
#define IMX_HSIO_CRR_PHYX1_BASE                 0x5F120000
#define IMX_HSIO_CRR_PHYX1_SIZE                 0x10000
#define IMX_HSIO_CRR_PHYX2_BASE                 0x5F110000
#define IMX_HSIO_CRR_PHYX2_SIZE                 0x10000
/* LPCG */
#define IMX_HSIO_LPCG_GPIO_BASE                 0x5F100000
#define IMX_HSIO_LPCG_GPIO_SIZE                 0x10000
#define IMX_HSIO_LPCG_CRR_5_BASE                0x5F0F0000
#define IMX_HSIO_LPCG_CRR_5_SIZE                0x10000
#define IMX_HSIO_LPCG_CRR_4_BASE                0x5F0E0000
#define IMX_HSIO_LPCG_CRR_4_SIZE                0x10000
#define IMX_HSIO_LPCG_CRR_3_BASE                0x5F0D0000
#define IMX_HSIO_LPCG_CRR_3_SIZE                0x10000
#define IMX_HSIO_LPCG_CRR_2_BASE                0x5F0C0000
#define IMX_HSIO_LPCG_CRR_2_SIZE                0x10000
#define IMX_HSIO_LPCG_CRR_1_BASE                0x5F0B0000
#define IMX_HSIO_LPCG_CRR_1_SIZE                0x10000
#define IMX_HSIO_LPCG_CRR_0_BASE                0x5F0A0000
#define IMX_HSIO_LPCG_CRR_0_SIZE                0x10000
#define IMX_HSIO_LPCG_PHYX1_BASE                0x5F090000
#define IMX_HSIO_LPCG_PHYX1_SIZE                0x10000
#define IMX_HSIO_LPCG_PHYX2_BASE                0x5F080000
#define IMX_HSIO_LPCG_PHYX2_SIZE                0x10000
#define IMX_HSIO_LPCG_PCIEB_BASE                0x5F060000
#define IMX_HSIO_LPCG_PCIEB_SIZE                0x10000
#define IMX_HSIO_LPCG_PCIEA_BASE                0x5F050000
#define IMX_HSIO_LPCG_PCIEA_SIZE                0x10000
#define IMX_CONNECTIVITY_LPCG_NAND_BASE         0x5B290000
#define IMX_CONNECTIVITY_LPCG_NAND_SIZE         0x10000

/* SATA AHCI */
#define IMX_SATA_BASE                           0x5F020000
#define IMX_SATA_SIZE                           0x10000
#define IMX_SATA_IRQ0                           120
#define IMX_SATA_IRQ1                           121

/*
 * LPI2C Controller (I2C)
 */
#define IMX_LSIO_I2C0_BASE                     0x5A800000
#define IMX_LSIO_I2C1_BASE                     0x5A810000
#define IMX_LSIO_I2C2_BASE                     0x5A820000
#define IMX_LSIO_I2C3_BASE                     0x5A830000
#define IMX_LSIO_I2C4_BASE                     0x5A840000

#define IMX_DC0_LVDS_I2C0_BASE                 0x56246000
#define IMX_DC0_LVDS_I2C1_BASE                 0x56247000
#define IMX_DC0_MIPI_I2C0_BASE                 0x56226000
#define IMX_DC0_MIPI_I2C1_BASE                 0x56227000
#define IMX_DC1_LVDS_I2C0_BASE                 0x57246000
#define IMX_DC1_LVDS_I2C1_BASE                 0x57247000
#define IMX_DC1_MIPI_I2C0_BASE                 0x57226000
#define IMX_DC1_MIPI_I2C1_BASE                 0x57227000
#define IMX_MIPI_CSI0_I2C0_BASE                0x58226000
#define IMX_MIPI_CSI1_I2C0_BASE                0x58246000
#define IMX_HDMI_RX_I2C0_BASE                  0x58266000
#define IMX_HDMI_TX_I2C0_BASE                  0x56266000
#define IMX_M40_I2C0_BASE                      0x37230000
#define IMX_M41_I2C0_BASE                      0x3B230000

#define IMX_LSIO_I2C0_IRQ                      252
#define IMX_LSIO_I2C1_IRQ                      253
#define IMX_LSIO_I2C2_IRQ                      254
#define IMX_LSIO_I2C3_IRQ                      255
#define IMX_LSIO_I2C4_IRQ                      256

#define IMX_DC0_LVDS_I2C0_IRQ                  (IMX_DC0_LVDS_STEER_IRQ0 + 0x08)
#define IMX_DC0_LVDS_I2C1_IRQ                  (IMX_DC0_LVDS_STEER_IRQ0 + 0x09)
#define IMX_DC1_LVDS_I2C0_IRQ                  (IMX_DC1_LVDS_STEER_IRQ0 + 0x08)
#define IMX_DC1_LVDS_I2C1_IRQ                  (IMX_DC1_LVDS_STEER_IRQ0 + 0x09)
#define IMX_DC0_MIPI_I2C0_IRQ                  (IMX_DC0_MIPI_STEER_IRQ0 + 0x08)
#define IMX_DC0_MIPI_I2C1_IRQ                  (IMX_DC0_MIPI_STEER_IRQ0 + 0x09)
#define IMX_DC1_MIPI_I2C0_IRQ                  (IMX_DC1_MIPI_STEER_IRQ0 + 0x08)
#define IMX_DC1_MIPI_I2C1_IRQ                  (IMX_DC1_MIPI_STEER_IRQ0 + 0x09)
#define IMX_MIPI_CSI0_I2C0_IRQ                 (IMX_MIPI_CSI0_STEER_IRQ0 + 0x08)
#define IMX_MIPI_CSI1_I2C0_IRQ                 (IMX_MIPI_CSI1_STEER_IRQ0 + 0x08)
#define IMX_HDMI_RX_I2C0_IRQ                   (IMX_HDMI_RX_STEER_IRQ0 + 0x08)
#define IMX_HDMI_TX_I2C0_IRQ                   (IMX_HDMI_TX_STEER_IRQ0 + 0x08)
#define IMX_M40_I2C0_IRQ                       (IMX_M40_INTMUX_BASE_IRQ0 + 0x09)
#define IMX_M41_I2C0_IRQ                       (IMX_M41_INTMUX_BASE_IRQ0 + 0x09)

#define IMX_LPI2C_SIZE                         0x10000
#define IMX_LPI2C_FIFO_SIZE                    0x4
#define IMX_LPI2C_COUNT                        19

/*
 * Low Power Universal Asynchronous Receiver/Transmitter (LPUART)
 */
#define IMX_LPUART0_BASE                       0x5A060000
#define IMX_LPUART1_BASE                       0x5A070000
#define IMX_LPUART2_BASE                       0x5A080000
#define IMX_LPUART3_BASE                       0x5A090000
#define IMX_LPUART4_BASE                       0x5A0A0000

#define IMX_LPUART0_IRQ                        257
#define IMX_LPUART1_IRQ                        258
#define IMX_LPUART2_IRQ                        259
#define IMX_LPUART3_IRQ                        260
#define IMX_LPUART4_IRQ                        261

#define IMX_LPUART_SIZE                        0x10000
#define IMX_LPUART_COUNT                       5

/*
 * Low Power Serial Peripheral Interface (LPSPI)
 */
#define IMX_LPSPI0_BASE                        0x5A000000
#define IMX_LPSPI1_BASE                        0x5A010000
#define IMX_LPSPI2_BASE                        0x5A020000
#define IMX_LPSPI3_BASE                        0x5A030000

#define IMX_LPSPI0_IRQ                         248
#define IMX_LPSPI1_IRQ                         249
#define IMX_LPSPI2_IRQ                         250
#define IMX_LPSPI3_IRQ                         251

#define IMX_LPSPI_SIZE                         0x10000
#define IMX_LPSPI_COUNT                        4

/*
 * Messaging unit (MU)
 */
/* MU 0 - 4 used for communication with the system controller (SCFW). */
#define IMX_MU0_BASE                           0x5D1B0000
#define IMX_MU1_BASE                           0x5D1C0000
#define IMX_MU2_BASE                           0x5D1D0000
#define IMX_MU3_BASE                           0x5D1E0000
#define IMX_MU4_BASE                           0x5D1F0000
/* MU 5 - 13 can be used for communication from AP to the M4/RPM cores. */
#define IMX_MU5A_BASE                          0x5D200000
#define IMX_MU6A_BASE                          0x5D210000
#define IMX_MU7A_BASE                          0x5D220000
#define IMX_MU8A_BASE                          0x5D230000
#define IMX_MU9A_BASE                          0x5D240000
#define IMX_MU10A_BASE                         0x5D250000
#define IMX_MU11A_BASE                         0x5D260000
#define IMX_MU12A_BASE                         0x5D270000
#define IMX_MU13A_BASE                         0x5D280000
/* MU B side from Cortex A core perspective. */
#define IMX_MU5B_BASE                          0x5D290000
#define IMX_MU6B_BASE                          0x5D2A0000
#define IMX_MU7B_BASE                          0x5D2B0000
#define IMX_MU8B_BASE                          0x5D2C0000
#define IMX_MU9B_BASE                          0x5D2D0000
#define IMX_MU10B_BASE                         0x5D2E0000
#define IMX_MU11B_BASE                         0x5D2F0000
#define IMX_MU12B_BASE                         0x5D300000
#define IMX_MU13B_BASE                         0x5D310000

#define IMX_MU0_IRQ                            208
#define IMX_MU1_IRQ                            209
#define IMX_MU2_IRQ                            210
#define IMX_MU3_IRQ                            211
#define IMX_MU4_IRQ                            212

#define IMX_MU5A_IRQ                           216
#define IMX_MU6A_IRQ                           217
#define IMX_MU7A_IRQ                           218
#define IMX_MU8A_IRQ                           219
#define IMX_MU9A_IRQ                           220
#define IMX_MU10A_IRQ                          221
#define IMX_MU11A_IRQ                          222
#define IMX_MU12A_IRQ                          223
#define IMX_MU13A_IRQ                          224

#define IMX_MU5B_IRQ                           232
#define IMX_MU6B_IRQ                           233
#define IMX_MU7B_IRQ                           234
#define IMX_MU8B_IRQ                           235
#define IMX_MU9B_IRQ                           236
#define IMX_MU10B_IRQ                          237
#define IMX_MU11B_IRQ                          238
#define IMX_MU12B_IRQ                          239
#define IMX_MU13B_IRQ                          240

#define IMX_MU_SIZE                            0x10000

/*
 * PCI Express (PCIe)
 */
#define IMX_PCIEA_BASE                         0x5F000000
#define IMX_PCIEB_BASE                         0x5F010000
#define IMX_PCIE_SIZE                          0x10000

/* PCIeA interrupts */
#define IMX_PCIEA_IRQ_A                        105
#define IMX_PCIEA_IRQ_B                        106
#define IMX_PCIEA_IRQ_C                        107
#define IMX_PCIEA_IRQ_D                        108
#define IMX_PCIEA_MSI                          102

/* PCIeB interrupts */
#define IMX_PCIEB_IRQ_A                        137
#define IMX_PCIEB_IRQ_B                        138
#define IMX_PCIEB_IRQ_C                        139
#define IMX_PCIEB_IRQ_D                        140
#define IMX_PCIEB_MSI                          134

/*
 * Universal Serial Bus Controller (USB)
 */
#define IMX_USB2OTG1_BASE                       0x5B0D0000
#define IMX_USB2PHY1_BASE                       0x5B100000
#define IMX_USB2_SIZE                           0x10000
#define IMX_USB2PHY1_SIZE                       0x10000
#define IMX_USB2OTG2_IRQ                        299

#define IMX_USB3_BASE                          0x5B110000
#define IMX_USB3_CTRL_BASE                     0x5B110000
#define IMX_USB3_CORE_BASE                     0x5B120000
#define IMX_USB3_PHY_BASE                      0x5B160000

#define IMX_USB3OTG1_IRQ                       303

/*
 * Ultra Secured Digital Host Controller (uSDHC)
 */
#define IMX_USDHC0_BASE                        0x5B010000
#define IMX_USDHC1_BASE                        0x5B020000
#define IMX_USDHC2_BASE                        0x5B030000

#define IMX_USDHC_SIZE                         0x10000
#define IMX_USDHC_MAP_SIZE                     0x100
#define IMX_USDHC_COUNT                        3

#define IMX_USDHC0_IRQ                         264
#define IMX_USDHC1_IRQ                         265
#define IMX_USDHC2_IRQ                         266

/*
 * 10/100/1000-Mbps Ethernet MAC (ENET)
 */
/* ENET - base addresses */
#define IMX_ENET0_BASE                         0x5B040000
#define IMX_ENET1_BASE                         0x5B050000

/* ENET - memory size */
#define IMX_ENET0_MEM_SIZE                     0x10000
#define IMX_ENET1_MEM_SIZE                     0x10000

/* ENET - interrupt vector numbers */
#define IMX_ENET0_IRQ                          290U
#define IMX_ENET1_IRQ                          294U

/*
 * Flexible SPI (FlexSPI)
 */
#define IMX_FLEXSPI0_BASE                      0x5D120000
#define IMX_FLEXSPI1_BASE                      0x5D130000

#define IMX_FLEXSPI_SIZE                       0x10000

#define IMX_FLEXSPI0_IRQ                       124
#define IMX_FLEXSPI1_IRQ                       125

/*
 * Asynchronous Sample Rate Converter (ASRC)
 */
#define IMX_ASRC0_BASE                         0x59000000
#define IMX_ASRC1_BASE                         0x59800000
#define IMX_ASRC0_IRQ                          405
#define IMX_ASRC1_IRQ                          412

#define IMX_ASRC_SIZE                          0x10000

/*
 * SECO
 */
#define IMX_SECO_SECURE_RAM_BASE                0x31800000UL
#define IMX_SECO_SECURE_RAM_SIZE                0x10000
#define IMX_SECO_LOCAL_SECURE_RAM_BASE          (0x60000000UL)

/*
 * Synchronous Audio Interface (SAI)
 */
#define IMX_SAI0_BASE                          0x59040000
#define IMX_SAI1_BASE                          0x59050000
#define IMX_SAI2_BASE                          0x59060000
#define IMX_SAI3_BASE                          0x59070000
#define IMX_SAI4_BASE                          0x59080000
#define IMX_SAI5_BASE                          0x59090000
#define IMX_SAI6_BASE                          0x59820000
#define IMX_SAI7_BASE                          0x59830000

#define IMX_SAI0_IRQ                           346
#define IMX_SAI1_IRQ                           348
#define IMX_SAI2_IRQ                           350
#define IMX_SAI3_IRQ                           355
#define IMX_SAI4_IRQ                           357
#define IMX_SAI5_IRQ                           359
#define IMX_SAI6_IRQ                           361
#define IMX_SAI7_IRQ                           363

#define IMX_SAI_SIZE                           0x10000
#define IMX_SAI_COUNT                          8

/*
 * Enhanced Serial Audio Interface  (ESAI)
 */
#define IMX_ESAI0_BASE                         0x59010000
#define IMX_ESAI1_BASE                         0x59810000

#define IMX_ESAI0_IRQ                          420
#define IMX_ESAI1_IRQ                          421

#define IMX_ESAI_SIZE                          0x10000
#define IMX_ESAI_COUNT                         2

/*
 * Audio Clock Mux (ACM)
 */
#define IMX_ACM_BASE                           0x59E00000

#define IMX_ACM_SIZE                           0x10000

/*
 * Flexible CAN (FlexCAN)
 */
#define IMX_FLEXCAN0_REG_BASE                  0x5A8D0000
#define IMX_FLEXCAN1_REG_BASE                  0x5A8E0000
#define IMX_FLEXCAN2_REG_BASE                  0x5A8F0000
#define IMX_FLEXCAN0_MEM_BASE                  0x5A8D0080
#define IMX_FLEXCAN1_MEM_BASE                  0x5A8E0080
#define IMX_FLEXCAN2_MEM_BASE                  0x5A8F0080
#define IMX_FLEXCAN0_IRQ                       267
#define IMX_FLEXCAN1_IRQ                       268
#define IMX_FLEXCAN2_IRQ                       269
#define IMX_FLEXCAN_COUNT                      3

/*
 * NAND
 */
#define IMX_APBH_BASE                          0x5B810000
#define IMX_APBH_SIZE                          0x1000
#define IMX_APBH_IRQ                           306

#define IMX_BCH_BASE                           0x5B814000
#define IMX_BCH_SIZE                           0x200
#define IMX_BCH_IRQ                            304
#define IMX_BCH_MAX_ECC                        62

#define IMX_GPMI_BASE                          0x5B812000
#define IMX_GPMI_SIZE                          0x200
#define IMX_GPMI_IRQ                           305

#endif /* IMX8QM_SOC_H_ */


#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
#ifdef __ASM__
__SRCVERSION "$URL: http://svn.ott.qnx.com/product/branches/7.0.0/trunk/hardware/startup/lib/public/aarch64/mx8m.h $ $Rev: 886103 $"
#else
__SRCVERSION( "$URL: http://svn.ott.qnx.com/product/branches/7.0.0/trunk/hardware/startup/lib/public/aarch64/mx8m.h $ $Rev: 886103 $" )
#endif
#endif
